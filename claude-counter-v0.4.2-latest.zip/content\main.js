(() => {
	'use strict';

	const CC = (globalThis.ClaudeCounter = globalThis.ClaudeCounter || {});
	console.log('[Claude Counter] Content script loading...');
	if (CC.__started) return;
	CC.__started = true;

	function getConversationId() {
		const match = window.location.pathname.match(/\/chat\/([^/?]+)/);
		return match ? match[1] : null;
	}

	function getOrgIdFromUrl() {
		const pathMatch = window.location.pathname.match(/\/organizations\/([^/]+)/);
		if (pathMatch) return pathMatch[1];
		
		// Fallback: Check for stored orgId (bridge finds it in state)
		return globalThis.CC_LAST_ORG_ID || null;
	}

	function getOrgIdFromCookie() {
		try {
			return document.cookie
				.split('; ')
				.find((row) => row.startsWith('lastActiveOrg='))
				?.split('=')[1] || null;
		} catch {
			return null;
		}
	}

	/**
	 * Wait for an element to appear in the DOM using MutationObserver.
	 * More efficient than polling - reacts immediately when element appears.
	 * @param {string} selector - CSS selector
	 * @param {number} [timeoutMs] - Optional timeout in ms. Returns null if timeout expires.
	 */
	function waitForElement(selector, timeoutMs) {
		return new Promise((resolve) => {
			const existing = document.querySelector(selector);
			if (existing) {
				resolve(existing);
				return;
			}

			let timeoutId;
			const observer = new MutationObserver(() => {
				const el = document.querySelector(selector);
				if (el) {
					if (timeoutId) clearTimeout(timeoutId);
					observer.disconnect();
					resolve(el);
				}
			});

			observer.observe(document.body, { childList: true, subtree: true });

			if (timeoutMs) {
				timeoutId = setTimeout(() => {
					observer.disconnect();
					resolve(null);
				}, timeoutMs);
			}
		});
	}

	CC.waitForElement = waitForElement;

	function observeUrlChanges(callback) {
		let lastPath = window.location.pathname;

		const fireIfChanged = () => {
			const current = window.location.pathname;
			if (current !== lastPath) {
				lastPath = current;
				callback();
			}
		};

		// Listen for custom event from bridge (history methods wrapped early)
		window.addEventListener('cc:urlchange', fireIfChanged);
		// Also popstate for back/forward buttons
		window.addEventListener('popstate', fireIfChanged);
		
		// Listen for orgId discovery from bridge
		window.addEventListener('cc:org_ready', (e) => {
			if (e.detail?.orgId && e.detail.orgId !== currentOrgId) {
				console.log('[Claude Counter] OrgId ready event received:', e.detail.orgId);
				updateOrgIdIfNeeded(e.detail.orgId);
				refreshUsage();
			}
		});

		return () => {
			window.removeEventListener('cc:urlchange', fireIfChanged);
			window.removeEventListener('popstate', fireIfChanged);
		};
	}

	function parseUsageFromUsageEndpoint(raw) {
		if (!raw || typeof raw !== 'object') return null;

		const normalizeWindow = (w, hours) => {
			if (!w || typeof w !== 'object') return null;
			if (typeof w.utilization !== 'number' || !Number.isFinite(w.utilization)) return null;
			const utilization = Math.max(0, Math.min(100, w.utilization));
			const resets_at = typeof w.resets_at === 'string' ? w.resets_at : null;
			return { utilization, resets_at, window_hours: hours };
		};

		const fiveHour = normalizeWindow(raw.five_hour, 5);
		const sevenDay = normalizeWindow(raw.seven_day, 24 * 7);

		if (!fiveHour && !sevenDay) return null;
		return { five_hour: fiveHour, seven_day: sevenDay };
	}

	function parseUsageFromMessageLimit(raw) {
		if (!raw?.windows || typeof raw.windows !== 'object') return null;

		const normalizeWindow = (w, hours) => {
			if (!w || typeof w !== 'object') return null;
			if (typeof w.utilization !== 'number' || !Number.isFinite(w.utilization)) return null;
			const utilization = Math.max(0, Math.min(100, w.utilization * 100));
			const resets_at = typeof w.resets_at === 'number' && Number.isFinite(w.resets_at)
				? new Date(w.resets_at * 1000).toISOString()
				: null;
			return { utilization, resets_at, window_hours: hours };
		};

		const fiveHour = normalizeWindow(raw.windows['5h'], 5);
		const sevenDay = normalizeWindow(raw.windows['7d'], 24 * 7);

		if (!fiveHour && !sevenDay) return null;
		return { five_hour: fiveHour, seven_day: sevenDay };
	}

	let currentConversationId = null;
	let currentOrgId = null;

	let usageState = null; // last snapshot
	let usageResetMs = { five_hour: null, seven_day: null }; // cached parsed timestamps
	let lastUsageSseMs = 0;
	let usageFetchInFlight = false;
	let lastUsageUpdateMs = 0;
	const rolloverHandledForResetMs = { five_hour: null, seven_day: null };

	// Settings state
	let settings = {
		thresholds: [80, 95],
		colors: {},
		showBreakdown: true,
		showLatency: true,
		showBadges: true,
		userHidden: false
	};

	chrome.runtime.onMessage.addListener((message) => {
		if (message.type === 'cc:toggle_visibility') {
			settings.userHidden = !settings.userHidden;
			chrome.storage.local.set({ settings });
			ui.applySettings(settings);
		}
	});

	const ui = new CC.ui.CounterUI({
		onUsageRefresh: async () => {
			await refreshUsage();
		},
		onSettingsChange: async (newSettings) => {
			settings = { ...settings, ...newSettings };
			await chrome.storage.local.set({ settings });
			ui.applySettings(settings);
		},
		onHistoryRequest: async () => {
			const res = await chrome.storage.local.get(['usageHistory']);
			return res.usageHistory || [];
		}
	});

	async function loadSettings() {
		const res = await chrome.storage.local.get(['settings']);
		if (res.settings) {
			settings = { ...settings, ...res.settings };
		}
		ui.applySettings(settings);
	}

	ui.initialize();
	loadSettings();

	// Bridge must be ready before we can make requests
	const bridgeReady = CC.injectBridgeOnce();

	function checkNotifications(normalized) {
		if (!normalized || !settings.thresholds?.length) return;
		const sessionPct = normalized.five_hour?.utilization || 0;
		
		for (const threshold of settings.thresholds) {
			const id = `cc-notif-${threshold}`;
			if (sessionPct >= threshold) {
				chrome.storage.local.get([id]).then((res) => {
					// Only notify once per window/reset
					const lastNotif = res[id] || 0;
					const resetTime = usageResetMs.five_hour || 0;
					if (lastNotif < resetTime - 5 * 60 * 60 * 1000 || lastNotif < Date.now() - 5 * 60 * 60 * 1000) {
						chrome.runtime.sendMessage({
							type: 'cc:notify',
							title: 'Claude Usage Alert',
							message: `You have reached ${Math.round(sessionPct)}% of your session limit.`
						});
						chrome.storage.local.set({ [id]: Date.now() });
					}
				});
			}
		}
	}

	async function recordUsageHistory(normalized) {
		if (!normalized) return;
		const res = await chrome.storage.local.get(['usageHistory']);
		const history = res.usageHistory || [];
		history.push({
			ts: Date.now(),
			session: normalized.five_hour?.utilization,
			weekly: normalized.seven_day?.utilization
		});
		// Keep last 30 days (roughly 1 snapshot per 15 min * 4 * 24 * 30 = 2880 entries)
		if (history.length > 3000) history.shift();
		await chrome.storage.local.set({ usageHistory: history });
	}

	function applyUsageUpdate(normalized, source) {
		console.log('[Claude Counter] Usage data received:', normalized, 'from:', source);
		if (!normalized) return;
		const now = Date.now();
		usageState = normalized;
		lastUsageUpdateMs = now;
		if (source === 'sse') lastUsageSseMs = now;
		// Cache parsed timestamps to avoid Date.parse() every tick
		usageResetMs.five_hour = normalized.five_hour?.resets_at ? Date.parse(normalized.five_hour.resets_at) : null;
		usageResetMs.seven_day = normalized.seven_day?.resets_at ? Date.parse(normalized.seven_day.resets_at) : null;
		ui.setUsage(normalized);
		
		recordUsageHistory(normalized);
		checkNotifications(normalized);
	}

	function updateOrgIdIfNeeded(newOrgId) {
		if (newOrgId && typeof newOrgId === 'string' && newOrgId !== currentOrgId) {
			currentOrgId = newOrgId;
		}
	}

	async function refreshUsage() {
		await bridgeReady;
		const orgId = getOrgIdFromUrl() || currentOrgId || getOrgIdFromCookie();
		if (!orgId) return;
		updateOrgIdIfNeeded(orgId);

		if (usageFetchInFlight) return;
		usageFetchInFlight = true;
		let raw;
		try {
			raw = await CC.bridge.requestUsage(orgId);
		} catch {
			return;
		} finally {
			usageFetchInFlight = false;
		}

		const parsed = parseUsageFromUsageEndpoint(raw);
		applyUsageUpdate(parsed, 'usage');
	}

	async function refreshConversation() {
		await bridgeReady;
		if (!currentConversationId) {
			ui.setConversationMetrics();
			return;
		}

		const orgId = getOrgIdFromUrl() || currentOrgId || getOrgIdFromCookie();
		if (!orgId) return;
		updateOrgIdIfNeeded(orgId);

		try {
			await CC.bridge.requestConversation(orgId, currentConversationId);
		} catch {
			// ignore
		}
	}

	function handleGenerationStart({ startTime }) {
		if (!currentConversationId) return;
		ui.setPendingCache(true);
		ui.setLatency({ startTime });
	}

	function handleTtft({ ttft }) {
		ui.setLatency({ ttft });
	}

	function handleGenerationEnd({ duration }) {
		ui.setLatency({ duration });
	}

	async function handleConversationPayload({ orgId, conversationId, data }) {
		if (!conversationId || conversationId !== currentConversationId) return;
		updateOrgIdIfNeeded(orgId);
		if (!data) return;

		const metrics = await CC.tokens.computeConversationMetrics(data);
		ui.setConversationMetrics(metrics);
	}

	function handleMessageLimit(messageLimit) {
		const parsed = parseUsageFromMessageLimit(messageLimit);
		applyUsageUpdate(parsed, 'sse');
	}

	CC.bridge.on('cc:generation_start', handleGenerationStart);
	CC.bridge.on('cc:generation_end', handleGenerationEnd);
	CC.bridge.on('cc:ttft', handleTtft);
	CC.bridge.on('cc:conversation', handleConversationPayload);
	CC.bridge.on('cc:message_limit', handleMessageLimit);

	async function handleUrlChange() {
		currentConversationId = getConversationId();

		// Attach usage line and header independently
		waitForElement(CC.DOM.MODEL_SELECTOR_DROPDOWN, 60000).then((el) => {
			if (el) {
				console.log('[Claude Counter] Found model selector, attaching usage line');
				ui.attachUsageLine();
			} else {
				console.warn('[Claude Counter] Model selector not found after 60s');
			}
		});
		waitForElement(CC.DOM.CHAT_MENU_TRIGGER, 60000).then((el) => {
			if (el) {
				console.log('[Claude Counter] Found chat menu, attaching header');
				ui.attachHeader();
			} else {
				console.warn('[Claude Counter] Chat menu not found after 60s');
			}
		});

		if (!currentConversationId) {
			ui.setConversationMetrics();
			// On homepage, still try to fetch usage for the org
			if (!usageState) refreshUsage();
			return;
		}

		// Best-effort orgId from cookie/url.
		updateOrgIdIfNeeded(getOrgIdFromUrl() || getOrgIdFromCookie());

		await refreshConversation();

		// Usage is org-level, not conversation-level.
		if (!usageState) await refreshUsage();
	}

	const unobserveUrl = observeUrlChanges(handleUrlChange);
	window.addEventListener('beforeunload', unobserveUrl);

	// Refresh on branch navigation
	let branchObserver = null;
	document.addEventListener('click', (e) => {
		if (!currentConversationId) return;
		const btn = e.target.closest('button[aria-label="Previous"], button[aria-label="Next"]');
		if (!btn) return;

		const container = btn.closest('.inline-flex');
		const spans = container?.querySelectorAll('span') || [];
		const indicator = Array.from(spans).find((s) => /^\d+\s*\/\s*\d+$/.test(s.textContent.trim()));
		if (!indicator) return;

		const originalText = indicator.textContent;
		if (branchObserver) branchObserver.disconnect();

		branchObserver = new MutationObserver(() => {
			if (indicator.textContent !== originalText) {
				branchObserver.disconnect();
				branchObserver = null;
				refreshConversation();
			}
		});

		branchObserver.observe(indicator, { childList: true, characterData: true, subtree: true });

		setTimeout(() => {
			if (branchObserver) {
				branchObserver.disconnect();
				branchObserver = null;
			}
		}, 60000);
	});

	// Initial attach + fetches
	handleUrlChange();

	function tick() {
		ui.tick();

		const now = Date.now();
		if (usageResetMs.five_hour && now >= usageResetMs.five_hour && rolloverHandledForResetMs.five_hour !== usageResetMs.five_hour) {
			rolloverHandledForResetMs.five_hour = usageResetMs.five_hour;
			refreshUsage();
		}
		if (usageResetMs.seven_day && now >= usageResetMs.seven_day && rolloverHandledForResetMs.seven_day !== usageResetMs.seven_day) {
			rolloverHandledForResetMs.seven_day = usageResetMs.seven_day;
			refreshUsage();
		}

		const ONE_HOUR_MS = 60 * 60 * 1000;
		const sseAge = now - lastUsageSseMs;
		const anyAge = now - lastUsageUpdateMs;
		if (!document.hidden && sseAge > ONE_HOUR_MS && anyAge > ONE_HOUR_MS) {
			refreshUsage();
		}
	}

	setInterval(tick, 1000);
})();
